# Brand assets — yousiffarra.com

Production-ready logo and favicon set. All SVG text is converted to paths — no font dependency, identical rendering on every browser and device.

## What's here

| File | Use |
|---|---|
| `logo.svg` | Primary logo (lockup) for light backgrounds — mark + name + tagline |
| `logo-dark.svg` | Lockup for dark backgrounds |
| `favicon.svg` | Modern SVG favicon — same `yf` mark as the lockup |
| `favicon-16.png` | Legacy browsers |
| `favicon-32.png` | Standard browser tab favicon |
| `favicon-180.png` | Apple touch icon (iOS home screen) |
| `favicon-512.png` | PWA manifest, social previews |
| `favicon-source.svg` | The `<YF/>` developer signature — alternate brand mark |
| `wordmark-yf.svg` | Bonus: `yf.` minimal wordmark with coral period accent |

The lockup's mark and the favicon are the same shape — so wherever the favicon appears (browser tab, bookmark, iOS home screen), it visually clicks with the full logo on your site.

## Install in Laravel

Drop the public files into `public/` and rename two for convention:

```
public/
├── logo.svg
├── logo-dark.svg
├── favicon.svg
├── favicon-16.png            ← rename to favicon-16x16.png if you prefer
├── favicon-32.png            ← rename to favicon-32x32.png if you prefer
├── apple-touch-icon.png      ← rename favicon-180.png to this
└── android-chrome-512x512.png ← rename favicon-512.png to this (for PWA)
```

Then in your layout `<head>` (e.g. `resources/views/layouts/app.blade.php`):

```html
<link rel="icon" type="image/svg+xml" href="{{ asset('favicon.svg') }}">
<link rel="icon" type="image/png" sizes="32x32" href="{{ asset('favicon-32.png') }}">
<link rel="icon" type="image/png" sizes="16x16" href="{{ asset('favicon-16.png') }}">
<link rel="apple-touch-icon" sizes="180x180" href="{{ asset('apple-touch-icon.png') }}">
```

Modern browsers pick the SVG; Safari and older browsers fall back to the PNG.

## Using the logo

The lockup is a horizontal asset — works best at heights between 32 and 80 px in headers:

```html
<a href="/" class="brand">
  <img src="{{ asset('logo.svg') }}" alt="Yousif Elfarra — Backend Laravel developer" height="48">
</a>
```

For dark-mode support with no JS:

```html
<picture>
  <source srcset="{{ asset('logo-dark.svg') }}" media="(prefers-color-scheme: dark)">
  <img src="{{ asset('logo.svg') }}" alt="Yousif Elfarra — Backend Laravel developer" height="48">
</picture>
```

For places too tight for the full lockup (mobile nav, app tabs, favicons), drop in `favicon.svg` — same mark, no wordmark.

## Brand palette

| Role | Hex | Where it's used |
|---|---|---|
| Indigo (primary) | `#4F46E5` | mark background, favicon |
| Dark slate (text) | `#0F172A` | name on light backgrounds |
| Slate muted | `#64748B` | tagline on light backgrounds |
| Slate divider | `#CBD5E1` | divider on light backgrounds |
| Coral (accent) | `#F97316` | the `.` in the bonus `yf.` mark |

## Typography

- Name (wordmark): **Poppins SemiBold** (600)
- Mark (`yf`): **Poppins Bold** (700)
- Tagline: **Poppins Regular** (400)
- Developer signature `<YF/>`: any monospace bold (Liberation Mono Bold used here)

Since all text is baked into SVG paths, you don't need to host these fonts to display the assets. But matching Poppins on your site's body type will tie the brand together.
